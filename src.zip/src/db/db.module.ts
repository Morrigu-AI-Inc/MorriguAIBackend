import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import QuerySchema from './schemas/Query';
import PromptFlagSchema from './schemas/PromptFlag';
import { PromptSchema } from './schemas/Prompt';
import EnvironmentSchema from './schemas/Environment';
import ProjectSchema from './schemas/Project';
import OrganizationSchema from './schemas/Organization';
import UserSchema from './schemas/User';
import ModelSchema from './schemas/APIkeys';
import { PromptflagService } from 'src/promptflag/promptflag.service';

@Module({
  imports: [
    MongooseModule.forFeature([
      {
        name: 'PromptFlag',
        schema: PromptFlagSchema,
        collection: 'promptFlags',
      },
    ]),
  ],
  providers: [PromptflagService],
})
export class DbModule {}
