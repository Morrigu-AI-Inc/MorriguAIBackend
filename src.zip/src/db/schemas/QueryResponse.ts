import { Schema, Document, Types } from 'mongoose';

// Define the interface for your document
export interface IQueryResponse extends Document {
  // Define your document properties here
  // For example:
  body: object;
  createdAt: Date;
  updatedAt: Date;
  owner: Types.ObjectId;
}

// Define the schema for your model
const QueryResponseSchema: Schema = new Schema(
  {
    // Define your schema properties here
    // For example:
    body: {
      type: Object,
      required: true,
    },
    owner: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  },
);

export default QueryResponseSchema;
