import { Document, Schema, Types } from 'mongoose';

export enum IntegrationTypes {
  AWS = 'aws',
}

export interface IntegrationSettings extends Document {
  _id: string;
  integration_name: string;
  integration_type: IntegrationTypes;
  integration_settings: any;
  owner: Types.ObjectId;
}

export const integrationData: {
  [key: string]: Pick<
    IntegrationSettings,
    'integration_name' | 'integration_type' | 'integration_settings'
  >;
} = {
  aws: {
    integration_name: 'AWS',
    integration_type: IntegrationTypes.AWS,
    integration_settings: {
      accessKey: 'string',
      secretKey: 'string',
      region: 'string',
    },
  },
};

export const IntegrationSettingsSchema = new Schema({
  integration_name: {
    type: String,
    required: true,
  },
  integration_type: {
    type: String,
    required: true,
  },
  integration_settings: {
    type: Schema.Types.Mixed,
    required: true,
  },
  owner: {
    type: Schema.Types.ObjectId,
    ref: 'Organization',
    required: true,
  },
});

export default IntegrationSettingsSchema;
