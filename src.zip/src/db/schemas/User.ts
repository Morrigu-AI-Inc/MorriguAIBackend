import { Schema, model } from 'mongoose';

export interface UserDocument extends Document {
  id: string;
  provider: string;
  email: string;
  name: string;
  data: unknown;
}

/**
 * This is the schema for the user model
 * The user model is used to store the user's information
 * @param email
 * @param name
 * @param picture
 * @param sub
 * @param updatedAt
 * @param createdAt
 * @returns
 */
export const UserSchema = new Schema<UserDocument>(
  {
    id: { type: String, required: true, unique: true },
    provider: { type: String, required: true },
    email: { type: String, required: false, unique: true },
    name: { type: String, required: true },
    data: { type: Schema.Types.Mixed },
  },
  { timestamps: true },
);



export default UserSchema;
