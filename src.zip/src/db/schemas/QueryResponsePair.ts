import { Schema, Document, Types } from 'mongoose';
import { IQuery } from './Query';
import { IQueryResponse } from './QueryResponse';

// Define the interface for your document
export interface IQueryResponsePair extends Document {
  query: Pick<IQuery, '_id' | 'body' | 'createdAt'>;
  response?: Pick<IQueryResponse, '_id' | 'body' | 'createdAt'>;
  createdAt: Date;
  updatedAt: Date;
  owner: Types.ObjectId;
}

// Define the schema for your model
export const QueryResponsePairSchema: Schema = new Schema(
  {
    query: {
      type: Schema.Types.ObjectId,
      ref: 'Query',
    },
    response: {
      type: Schema.Types.ObjectId,
      ref: 'QueryResponse',
      required: false,
    },
    owner: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  { timestamps: true },
);

// Create and export the model

export default QueryResponsePairSchema;
