import mongoose, { Schema, Document } from 'mongoose';

// This ultimate will be what calculates the billing for the organization
interface BillingPlan extends Document {
  name: string;
  description: string;
  price_per_seat: number;
  seats: number;
}

// so we can create some frontend types
interface Tier extends Document {
  name: string;
  description: string;
  billing_plan: mongoose.Types.ObjectId;
}

// Create the BillingPlan schema
interface Billing extends Document {
  plan: mongoose.Types.ObjectId;
  tier?: mongoose.Types.ObjectId;
}

export const BillingPlanSchema: Schema = new Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  price_per_seat: { type: Number, required: true },
  seats: { type: Number, required: true },
});

export const TierSchema: Schema = new Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  billing_plan: {
    type: mongoose.Types.ObjectId,
    ref: 'BillingPlan',
    required: true,
  },
});

export const BillingSchema: Schema = new Schema({
  plan: { type: mongoose.Types.ObjectId, ref: 'BillingPlan', required: true },
  tier: { type: mongoose.Types.ObjectId, ref: 'Tier' },
});
