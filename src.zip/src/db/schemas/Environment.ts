import { randomUUID } from 'crypto';
import { Schema, Document, Types } from 'mongoose';

export interface IEnvironment extends Document {
  name: string;
  key: string;
  tags: string[];
  critical: boolean;
  sdkKey: string;
  mobileKey: string;
  clientId: string;
  owner: Types.ObjectId;
  createdAt: Date;
  updatedAt: Date;
}

const EnvironmentSchema: Schema = new Schema(
  {
    name: {
      type: String,
      required: true,
    },
    key: {
      type: String,
      required: true,
    },
    tags: {
      type: [String],
      default: [],
    },
    critical: {
      type: Boolean,
      default: false,
    },
    sdkKey: {
      type: String,
      required: false,
      default: randomUUID,
    },
    mobileKey: {
      type: String,
      required: false,
      default: randomUUID,
    },
    clientId: {
      type: String,
      required: false,
      default: randomUUID,
    },
    owner: {
      type: Schema.Types.ObjectId,
      ref: 'Organization',
      required: true,
    },
  },
  {
    timestamps: true,
  },
);

export default EnvironmentSchema;
