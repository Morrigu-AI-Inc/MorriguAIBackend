import { Schema, Document } from 'mongoose';

// Define the interface for your document
export interface IQuery extends Document {
  // Define your document properties here
  body: object;
  createdAt: Date;
  updatedAt: Date;
  owner: string;
}

// Define the schema for your model
const QuerySchema: Schema = new Schema(
  {
    // Define your schema properties here
    body: {
      type: Object,
      required: true,
    },
    owner: {
      type: Schema.Types.ObjectId,
      ref: 'User',
    },
  },
  {
    timestamps: true,
  },
);

// Define and export your model

export default QuerySchema;
