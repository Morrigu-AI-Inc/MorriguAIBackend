import { Schema } from 'mongoose';

interface ACL extends Document {
  permissions: string[];
}

interface OrganizationACL extends ACL {}

interface UserACL extends ACL {}

export const OrganizationACLSchema: Schema = new Schema({
  permissions: [{ type: String, required: true, default: [] }],
});

export const UserACLSchema: Schema = new Schema({
  permissions: [{ type: String, required: true, default: [] }],
});

// Create the ACL model
// export const OrganizationACLModel = getModel<OrganizationACL>(
//   'OrganizationACL',
//   OrganizationACLSchema,
// );
// export const UserACLModel = getModel<UserACL>('UserACL', UserACLSchema);
