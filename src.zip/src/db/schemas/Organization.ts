import mongoose, { Schema, Document } from 'mongoose';

export interface Organization extends Document {
  name: string;
  description: string;
  owner: mongoose.Types.ObjectId;
  users: mongoose.Types.ObjectId[];
  default_acl: mongoose.Types.ObjectId;
  billing: mongoose.Types.ObjectId;
  projects: mongoose.Types.ObjectId[];
}

// Create the Organization schema
const OrganizationSchema: Schema = new Schema(
  {
    name: { type: String, required: true },
    description: { type: String, required: true },
    owner: { type: mongoose.Types.ObjectId, ref: 'User', required: true },
    users: [{ type: mongoose.Types.ObjectId, ref: 'User' }],
    default_acl: {
      type: mongoose.Types.ObjectId,
      ref: 'OrganizationACL',
      required: true,
    },
    billing: { type: mongoose.Types.ObjectId, ref: 'Billing', required: true },
    projects: [{ type: mongoose.Types.ObjectId, ref: 'Project', default: [] }],
  },
  {
    timestamps: true,
  },
);

// Create the Organization model


export default OrganizationSchema;
