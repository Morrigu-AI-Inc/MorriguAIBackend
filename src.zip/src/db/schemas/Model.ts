import { Schema, Document, Types } from 'mongoose';

// Define the configuration schema
export interface IModel extends Document {
  name: string;
  framework: 'aws' | 'openai' | 'google' | 'azure';
  modelId: string;
  inference_parameters: Array<{
    type: typeof Schema.Types.ObjectId;
    ref: 'InferenceParameters';
  }>;
  inference_params: unknown;
  model_formatting: {
    type: typeof Schema.Types.ObjectId;
    ref: 'ModelFormatting';
  };
  enableHistory: boolean;
  enableStreaming: boolean;
  enableChat: boolean;
  allowUserInterruption: boolean;
  owner: Types.ObjectId;
  project: Types.ObjectId;
  environment: Types.ObjectId;
}

export const modelSchema: Schema = new Schema<IModel>(
  {
    name: { type: String, required: true },
    framework: { type: String, required: true },
    modelId: { type: String, required: true },
    inference_parameters: {
      type: [
        {
          type: Schema.Types.ObjectId,
          ref: 'InferenceParameters',
        },
      ],
      default: [],
    },
    inference_params: { type: Schema.Types.Mixed, required: true },
    model_formatting: { type: Schema.Types.ObjectId, ref: 'ModelFormatting' },
    enableHistory: { type: Boolean, required: true, default: true },
    enableStreaming: { type: Boolean, required: true, default: true },
    enableChat: { type: Boolean, required: true, default: false },
    allowUserInterruption: { type: Boolean, required: false, default: false },
    owner: { type: Schema.Types.ObjectId, ref: 'Organization' },
    project: { type: Schema.Types.ObjectId, ref: 'Project' },
    environment: { type: Schema.Types.ObjectId, ref: 'Environment' },
  },
  {
    timestamps: true,
    versionKey: false,
    strict: false,
  },
);

interface ModelFormatting extends Document {
  system_prefix: string;
  system_suffix: string;
  user_prefix: string;
  user_suffix: string;
  assistant_prefix: string;
  assistant_suffix: string;
}

export const modelFormattingSchema: Schema = new Schema<ModelFormatting>(
  {
    system_prefix: { type: String, required: true },
    system_suffix: { type: String, required: true },
    user_prefix: { type: String, required: true },
    user_suffix: { type: String, required: true },
    assistant_prefix: { type: String, required: true },
    assistant_suffix: { type: String, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  },
);
