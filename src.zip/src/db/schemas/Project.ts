import mongoose, { Schema, Document } from 'mongoose';

export interface Project extends Document {
  _id: string;
  name: string;
  description: string;
  owner: mongoose.Types.ObjectId;
}

// Create the Project schema

const ProjectSchema: Schema = new Schema({
  name: { type: String, required: true },
  description: { type: String, required: true },
  owner: { type: mongoose.Types.ObjectId, ref: 'Organization', required: true }
});

// Create the Project model


export default ProjectSchema;
