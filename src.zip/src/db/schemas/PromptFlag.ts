import { Schema, Types } from 'mongoose';

export { Document } from 'mongoose';

export interface IPromptFlag extends Document {
  _id: string;
  promptId: Types.ObjectId;
  name: string;
  environment: Types.ObjectId;
  project: Types.ObjectId;
  owner: Types.ObjectId;
  createdBy: Types.ObjectId;
}

export const PromptFlagSchema: Schema = new Schema<IPromptFlag>(
  {
    promptId: {
      type: Schema.Types.ObjectId,
      ref: 'Prompt',
      required: true
    },
    name: {
      type: String,
      required: true
    },
    environment: {
      type: Schema.Types.ObjectId,
      ref: 'Environment',
      required: true
    },
    project: {
      type: Schema.Types.ObjectId,
      ref: 'Project',
      required: true
    },
    owner: { type: Schema.Types.ObjectId, ref: 'Organization', required: true },
    createdBy: { type: Schema.Types.ObjectId, ref: 'User' }
  },
  {
    timestamps: true
  }
);



export default PromptFlagSchema;
