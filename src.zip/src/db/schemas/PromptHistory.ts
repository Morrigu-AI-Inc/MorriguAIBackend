import { Schema, Document, Types } from 'mongoose';

// Define the PromptHistory schema
export interface IPromptHistory extends Document {
  promptFlagId: Types.ObjectId;
  history: Types.Array<Types.ObjectId>;
  owner: Types.ObjectId;
}

export const PromptHistorySchema = new Schema<IPromptHistory>(
  {
    promptFlagId: { type: Schema.Types.ObjectId, ref: 'PromptFlag' },
    history: [{ type: Schema.Types.ObjectId, ref: 'QueryResponsePair' }],
    owner: { type: Schema.Types.ObjectId, ref: 'User' },
  },
  {
    timestamps: true,
  },
);

// Create the models

export default PromptHistorySchema;
