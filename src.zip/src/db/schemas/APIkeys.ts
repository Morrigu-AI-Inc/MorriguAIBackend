import { Schema, Document } from 'mongoose';

const MODEL_NAME = 'APIKeys';

// Define the configuration schema
interface APIKeys extends Document {
  value: string | number | Array<string | number>;
  key: string;
}

const ModelSchema: Schema = new Schema<APIKeys>(
  {
    value: { type: Schema.Types.Mixed, required: true },
    key: { type: String, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  },
);



export default ModelSchema;
