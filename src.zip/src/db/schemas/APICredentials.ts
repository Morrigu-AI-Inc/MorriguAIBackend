import { v4 } from 'uuid';
import mongoose, { Document, Schema } from 'mongoose';

export interface ICredentials extends Document {
  clientId: string;
  secretKey: string;
  clientEnvId: {
    type: typeof Schema.Types.ObjectId;
    ref: 'Environment';
  };
  owner: mongoose.Types.ObjectId[];
}

export const CredentialsSchema = new Schema<ICredentials>({
  clientId: { type: String, required: true, default: v4(), unique: true },
  secretKey: { type: String, required: true, default: v4(), unique: true },
  clientEnvId: { type: Schema.Types.ObjectId, ref: 'Environment' },
  owner: [{ type: Schema.Types.ObjectId, ref: 'User' }],
});

export default CredentialsSchema;
