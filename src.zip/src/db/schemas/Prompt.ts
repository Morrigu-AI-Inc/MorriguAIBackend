import { uniqueId } from 'lodash';
import { Schema, model } from 'mongoose';

const MODEL_NAME = 'Prompt';

export type InputOuputFormat = {
  name: string;
  type: string;
  input: string;
};

interface InputDocument extends Document {
  name: string;
  type: string;
  input: string;
}

interface OutputDocument extends Document {
  name: string;
  type: string;
  output: string;
}

// Define the configuration schema
export interface PromptDocument extends Document {
  _id: string;
  name: string;
  version: string;
  system_message: string;
  modelId: {
    type: typeof Schema.Types.ObjectId;
    ref: 'Model';
  };
  inputs: Array<{
    type: typeof Schema.Types.ObjectId;
    ref: 'InputDocument';
  }>;
  outputs: Array<{
    type: typeof Schema.Types.ObjectId;
    ref: 'OutputDocument';
  }>;
  createdBy: {
    type: typeof Schema.Types.ObjectId;
    ref: 'User';
  };
  owner: {
    type: typeof Schema.Types.ObjectId;
    ref: 'User';
  };
  environment: {
    type: typeof Schema.Types.ObjectId;
    ref: 'Environment';
  };
  project: {
    type: typeof Schema.Types.ObjectId;
    ref: 'Project';
  };
}

export const PromptSchema = new Schema<PromptDocument>(
  {
    name: { type: String, required: true },
    version: { type: String, required: true, unique: true, default: uniqueId },
    system_message: { type: String, required: true },
    modelId: {
      type: Schema.Types.ObjectId,
      ref: 'Model',
      required: true,
    },
    inputs: {
      type: [
        {
          type: Schema.Types.ObjectId,
          ref: 'InputDocument',
        },
      ],
      default: [],
    },
    outputs: {
      type: [
        {
          type: Schema.Types.ObjectId,
          ref: 'OutputDocument',
        },
      ],
      default: [],
      required: true,
    },
    createdBy: {
      type: Schema.Types.ObjectId,
      ref: 'User', // This must match the name given to mongoose.model() for UserSchema
      required: true,
    },
    owner: {
      type: Schema.Types.ObjectId,
      ref: 'User', // This must match the name given to mongoose.model() for UserSchema
      required: true,
    },
    environment: {
      type: Schema.Types.ObjectId,
      ref: 'Environment',
      required: true,
    },
    project: {
      type: Schema.Types.ObjectId,
      ref: 'Project',
      required: true,
    },
  },
  { timestamps: true },
);

export const InputDocumentModel = new Schema<InputDocument>({
  name: String,
  type: String,
  input: String,
});
export const OutputDocumentModel = new Schema<OutputDocument>({
  name: String,
  type: String,
  output: String,
});
