import { Schema, Document } from 'mongoose';

const MODEL_NAME = 'InferenceParameters';

// Define the configuration schema
export interface IInferenceParameters extends Document {
  value: string | number | Array<string | number>;
  key: string;
}

export interface AnthropicInferenceParameters extends IInferenceParameters {
  modelId: string;
}

const InferenceParameters: Schema = new Schema<IInferenceParameters>(
  {
    value: { type: Schema.Types.Mixed, required: true },
    key: { type: String, required: true },
  },
  {
    timestamps: true,
    versionKey: false,
  },
);

export default InferenceParameters;
