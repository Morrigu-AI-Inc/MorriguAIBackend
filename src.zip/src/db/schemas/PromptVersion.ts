import { randomUUID } from 'crypto';
import { Schema, Document, Types } from 'mongoose';

export interface IPromptVersion extends Document {
  promptId: string;
  version: string;
  body: string;
  owner: Types.ObjectId;
  project: Types.ObjectId;
  environment: Types.ObjectId;
}

export const PromptVersionSchema: Schema = new Schema(
  {
    promptId: {
      type: Schema.Types.ObjectId,
      ref: 'Prompt',
      required: true,
    },
    version: {
      type: String,
      required: true,
      default: randomUUID(),
    },
    body: {
      type: String,
      required: true,
    },
    owner: { type: Schema.Types.ObjectId, ref: 'Organization' },
    project: { type: Schema.Types.ObjectId, ref: 'Project' },
    environment: { type: Schema.Types.ObjectId, ref: 'Environment' },
  },
  {
    timestamps: true,
  },
);
