import { Module } from '@nestjs/common';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { AuthModule } from './auth/auth.module';
import { ConfigModule } from '@nestjs/config';
import { AuthController } from './auth/auth.controller';
import { AuthService } from './auth/auth.service';
import { MessagesModule } from './messages/messages.module';
import { HttpModule } from '@nestjs/axios';
import { BedrockController } from './bedrock/bedrock.controller';
import { BedrockService } from './bedrock/bedrock.service';
import { BedrockModule } from './bedrock/bedrock.module';
import { MongooseModule } from '@nestjs/mongoose';
import { DbModule } from './db/db.module';
import { PromptflagService } from './promptflag/promptflag.service';
import { PromptService } from './prompt/prompt.service';
import { PromptflagModule } from './promptflag/promptflag.module';

@Module({
  imports: [
    AuthModule,
    ConfigModule.forRoot({
      isGlobal: true,
    }),
    MessagesModule,
    HttpModule,
    BedrockModule,
    MongooseModule.forRoot(process.env.MONGODB_URI),
    DbModule,
    PromptflagModule,
  ],
  controllers: [AppController, AuthController, BedrockController],
  providers: [AppService, AuthService, BedrockService, PromptService, PromptflagService],
})
export class AppModule {}
