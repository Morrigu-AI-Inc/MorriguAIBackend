import { Injectable } from '@nestjs/common';
import {
  BedrockRuntimeClient,
  InvokeModelWithResponseStreamCommand,
  ResponseStream,
} from '@aws-sdk/client-bedrock-runtime'; // ES Modules import

type BodyProps = {
  prompt: string;
  temperature?: number;
  top_p?: number;
  top_k?: number;
  max_tokens_to_sample: number;
  stop_sequences?: Array<string>;
};

@Injectable()
export class BedrockService {
  InvokeModelWithResponseStream = async (body: BodyProps, modelId) => {
    const bedrock = new BedrockRuntimeClient({ region: 'us-east-1' });

    const input = {
      // InvokeModelRequest
      body: JSON.stringify({
        ...body,
      }), // required
      contentType: 'application/json',
      accept: 'application/json',
      modelId: modelId,
    };
    const command = new InvokeModelWithResponseStreamCommand(input);
    const response = await bedrock.send(command);

    return response.body as AsyncIterable<ResponseStream>;
  };
}
