import { Module } from '@nestjs/common';
import { MongooseModule } from '@nestjs/mongoose';
import PromptFlagSchema from 'src/db/schemas/PromptFlag';
import { PromptflagService } from 'src/promptflag/promptflag.service';
import { BedrockController } from './bedrock.controller';

@Module({
  providers: [PromptflagService],
  controllers: [BedrockController],
  imports: [
    MongooseModule.forFeature([
      { name: 'PromptFlag', schema: PromptFlagSchema },
      // Add other models here as needed
    ]),
  ],
  exports: [PromptflagService],
})
export class BedrockModule {}
