export interface Message {
  readonly text: string;
}

export interface ErrorMessage {
  readonly message: string;
}
