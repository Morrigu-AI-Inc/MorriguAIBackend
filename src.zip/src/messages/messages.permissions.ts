export enum MessagesPermissions {
  READ_ADMIN = 'read:admin-messages',
}
