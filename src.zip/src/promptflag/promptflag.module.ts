import { Module } from '@nestjs/common';
import { PromptflagService } from './promptflag.service';
import { MongooseModule } from '@nestjs/mongoose';
import PromptFlagSchema from 'src/db/schemas/PromptFlag';

@Module({
  imports: [
    MongooseModule.forFeature([
      { name: 'PromptFlag', schema: PromptFlagSchema },
    ]),
  ],
  providers: [PromptflagService],
})
export class PromptflagModule {}
